# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
wikidata_prepared_joined = dataiku.Dataset("wikidata_prepared_joined")
wikidata_prepared_joined_df = wikidata_prepared_joined.get_dataframe()


# Dédoublonner les lignes strictement identiques :
wikidata_prepared_joined_2_df = wikidata_prepared_joined_df.drop_duplicates(subset="Matricule")

# Write recipe outputs
wikidata_prepared_joined_2 = dataiku.Dataset("wikidata_prepared_joined_2")
wikidata_prepared_joined_2.write_with_schema(wikidata_prepared_joined_2_df)
